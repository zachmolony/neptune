const stripe = require("stripe")("sk_test_7HobkYqAO6exIj2b4PO25KUN", {
  apiVersion: "2018-08-23; orders_beta=v4"
});

const fetchOrders = async (req, res) => {
  const orders = await stripe.orders.list({
    limit: 20
  });

  const completedOrders = orders.data.filter(
    (order) => order.status === "complete"
  );
  res.send(completedOrders);
};

module.exports = {
  fetchOrders
};
